﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagement.Models
{
    public class Employee
    {
        [Key]
        [DisplayName("ID")]
        public int Emp_ID { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("Name")]
        public string Emp_Name { get; set; }
        [Required]
        [DisplayName("Age")]
        public int Emp_Age { get; set; }
        [Required]
        [MaxLength(10)]
        [DisplayName("Gender")]
        public string Gender { get; set; }
        [Required]
        [DisplayName("DOJ")]
        public DateTime Doj { get; set; }
        [Required]
        [MaxLength(100)]
        [DisplayName("Designation")]
        public string Designation {  get; set; }
        
        public int Salary { get; set; }

    }
}
